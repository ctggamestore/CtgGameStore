CTG. GAME STORE - Starter Website

Included:
- Responsive one-page Free Fire diamond storefront
- Package selection
- Player UID and phone form
- WhatsApp order request to 01810434929
- Demo prices based on the prices previously supplied

Important:
- This is a front-end starter site, not a live automatic top-up system.
- No payment is collected on the page.
- No automatic diamond delivery is connected.
- Before selling, verify prices, supplier legitimacy, server/region, payment details, refund policy, and API authorization.
- Do not ask customers for passwords or OTPs.

To preview:
Open index.html in a browser.

For WordPress:
This standalone HTML file cannot be installed as a theme on the free WordPress.com plan.
You can use it as a design reference, or host it as a static site. Full WooCommerce/plugin/API integration requires a compatible WordPress hosting plan and secure server-side development.
